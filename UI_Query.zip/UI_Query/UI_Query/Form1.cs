﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;
using System.IO;

namespace UI_Query
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            // Koneksi ke server MySQL

            string connStr = "server=localhost; user=root; database=jual ;port=3306; password=;";
            MySqlConnection conn = new MySqlConnection(connStr);

            ////Ini adalah perintah query untuk insert/ input sejumlah data ke dalam database jual dan tabel jual_local
            //string QueryLoc = "INSERT INTO jual_local (RecordDate, BuahID, Qty, RecID) VALUES ('2022-07-01', 'APEL', 10, 1)," +
            //    "('2022-07-02', 'MARKISA', 10, 2)," +
            //    "('2022-07-04', 'SALAK', 30, 4)," +
            //    "('2022-07-05', 'PEPAYA',10, 5)," +
            //    "('2022-07-06', 'PEPAYA',10, 6)," +
            //    "('2022-07-07', 'APEL', 10, 7)," +
            //    "('2022-07-08', 'MANGGIS', 10, 8)," +
            //    "('2022-07-09', 'PEPAYA',10, 9)";

            ////Ini adalah perintah query untuk insert/ input sejumlah data ke dalam database jual dan tabel jual_sync
            //string QuerySync = "INSERT INTO jual_sync (RecordDate, BuahID, Qty, RecID) VALUES ('2022-07-01', 'APEL', 10, 1)," +
            //   "('2022-07-02', 'JERUK', 10, 2)," +
            //    "('2022-07-03', 'APEL', 10, 3)," +
            //    "('2022-07-04', 'SALAK', 10, 4)," +
            //    "('2022-07-05', 'PEPAYA',10, 5)," +
            //    "('2022-07-06', 'PEPAYA',10, 6)," +
            //    "('2022-07-07', 'APEL', 10, 7)";

            //MySqlCommand MyCommand1 = new MySqlCommand(QueryLoc, conn);
            //MySqlCommand MyCommand2 = new MySqlCommand(QuerySync, conn);


            try
            {
                for (int i = 0; i <= 100; i += 2)
                {
                    progressBar1.Value = i;
                    System.Threading.Thread.Sleep(5);
                }
                conn.Open();

                // Manual INSERT untuk tabel result
                //string Query = "INSERT INTO data_update (RecordDate, No, BuahID_Baru, BuahID_Lama, Qty_Baru, RunningTotal, Qty_Lama, TransactionGroup, TransactionStatus, StatusText, RecID) " +
                //"VALUES ('2022-07-01', 1, 'APEL', 'APEL', 10, 10, 10, 'KEEP', 'MATCH', 'NULL', 1)";
                //MySqlCommand MyCommand3 = new MySqlCommand(Query, conn);
                //MySqlDataReader MyReader2;
                //MyReader2 = MyCommand2.ExecuteReader();

                MessageBox.Show("Conn successfully......");
                progressBar1.Value = 0;


                // Hitung jumlah buah yang ter-register dengan katakunci BuahID_Lama
                string numb = "SELECT COUNT * FROM data_update WHERE BuahID_Lama = 'APLE'";
                MySqlCommand read_buah = new MySqlCommand(numb, conn);
                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
                string total = count.ToString();
                int new_total_buah = count + 1;
                int update_qty = new_total_buah * 10;




                // Perintah membaca seluruh data yang ada pada tabel jual_local dengan memberikan perintah ascending(a->z/1->9) sesuai urutan RecordDate dan ditampilkan dalam table
                string sql_local = "SELECT * FROM jual_local WHERE 1 ORDER BY RecordDate ASC";
                MySqlCommand cmd = new MySqlCommand(sql_local, conn);
                MySqlDataReader rdr_jual_local = cmd.ExecuteReader();
                while (rdr_jual_local.Read())
                {
                    DataTable data_jual_local = new DataTable();
                    data_jual_local.Columns.Add("RecordDate");
                    data_jual_local.Columns.Add("BuahID");
                    data_jual_local.Columns.Add("Qty");
                    data_jual_local.Columns.Add("RecID");

                    DataRow rows = data_jual_local.NewRow();
                    rows["RecordDate"] = rdr_jual_local[0].ToString();
                    rows["BuahID"] = rdr_jual_local[1].ToString();
                    rows["Qty"] = rdr_jual_local[2].ToString();
                    rows["RecID"] = rdr_jual_local[3].ToString();

                    data_jual_local.Rows.Add(rows);
                    foreach (DataRow Draw in data_jual_local.Rows)
                    {
                        int num = dataGridView2.Rows.Add();
                        dataGridView2.Rows[num].Cells[0].Value = Draw["RecordDate"].ToString();
                        dataGridView2.Rows[num].Cells[1].Value = Draw["BuahID"].ToString();
                        dataGridView2.Rows[num].Cells[2].Value = Draw["Qty"].ToString();
                        dataGridView2.Rows[num].Cells[3].Value = Draw["RecID"].ToString();

                    }

                }
                rdr_jual_local.Close();



                // Perintah membaca seluruh data yang ada pada tabel jual_local dengan memberikan perintah ascending(a->z/1->9) sesuai urutan RecordDate
                string sql_sync = "SELECT * FROM jual_sync WHERE 1 ORDER BY RecordDate ASC";
                MySqlCommand cmd_sync = new MySqlCommand(sql_sync, conn);
                MySqlDataReader rdr_jual_sync = cmd_sync.ExecuteReader();
                while (rdr_jual_sync.Read())
                {
                    DataTable data_jual_sync = new DataTable();
                    data_jual_sync.Columns.Add("RecordDate");
                    data_jual_sync.Columns.Add("BuahID");
                    data_jual_sync.Columns.Add("Qty");
                    data_jual_sync.Columns.Add("RecID");

                    DataRow rows = data_jual_sync.NewRow();
                    rows["RecordDate"] = rdr_jual_sync[0].ToString();
                    rows["BuahID"] = rdr_jual_sync[1].ToString();
                    rows["Qty"] = rdr_jual_sync[2].ToString();
                    rows["RecID"] = rdr_jual_sync[3].ToString();

                    data_jual_sync.Rows.Add(rows);
                    foreach (DataRow Draw in data_jual_sync.Rows)
                    {
                        int num = dataGridView3.Rows.Add();
                        dataGridView3.Rows[num].Cells[0].Value = Draw["RecordDate"].ToString();
                        dataGridView3.Rows[num].Cells[1].Value = Draw["BuahID"].ToString();
                        dataGridView3.Rows[num].Cells[2].Value = Draw["Qty"].ToString();
                        dataGridView3.Rows[num].Cells[3].Value = Draw["RecID"].ToString();

                    }

                }
                rdr_jual_sync.Close();




                // Perintah membaca seluruh data yang ada pada tabel jual_local dengan memberikan perintah ascending(a->z/1->9) sesuai urutan RecordDate
                string sql_result = "SELECT * FROM data_update WHERE 1 ORDER BY RecordDate ASC";
                MySqlCommand cmd_result = new MySqlCommand(sql_result, conn);
                MySqlDataReader rdr_result = cmd_result.ExecuteReader();
                while (rdr_result.Read())
                {
                    DataTable data_result = new DataTable();
                    data_result.Columns.Add("RecordDate");
                    data_result.Columns.Add("No");
                    data_result.Columns.Add("BuahID_Baru");
                    data_result.Columns.Add("BuahID_Lama");
                    data_result.Columns.Add("Qty_Baru");
                    data_result.Columns.Add("RunningTotal");
                    data_result.Columns.Add("Qty_Lama");
                    data_result.Columns.Add("TransactionGroup");
                    data_result.Columns.Add("TransactionStatus");
                    data_result.Columns.Add("StatusText");
                    data_result.Columns.Add("RecID");

                    DataRow rows = data_result.NewRow();
                    rows["RecordDate"] = rdr_result[0].ToString();
                    rows["No"] = rdr_result[1].ToString();
                    rows["BuahID_Baru"] = rdr_result[2].ToString();
                    rows["BuahID_Lama"] = rdr_result[3].ToString();
                    rows["Qty_Baru"] = rdr_result[4].ToString();
                    rows["RunningTotal"] = rdr_result[5].ToString();
                    rows["Qty_Lama"] = rdr_result[6].ToString();
                    rows["TransactionGroup"] = rdr_result[7].ToString();
                    rows["TransactionStatus"] = rdr_result[8].ToString();
                    rows["StatusText"] = rdr_result[9].ToString();
                    rows["RecID"] = rdr_result[10].ToString();

                    data_result.Rows.Add(rows);
                    foreach (DataRow Draw in data_result.Rows)
                    {
                        int num = dataGridView1.Rows.Add();
                        dataGridView1.Rows[num].Cells[0].Value = Draw["RecordDate"].ToString();
                        dataGridView1.Rows[num].Cells[1].Value = Draw["No"].ToString();
                        dataGridView1.Rows[num].Cells[2].Value = Draw["BuahID_Baru"].ToString();
                        dataGridView1.Rows[num].Cells[3].Value = Draw["BuahID_Lama"].ToString();
                        dataGridView1.Rows[num].Cells[4].Value = Draw["Qty_Baru"].ToString();
                        dataGridView1.Rows[num].Cells[5].Value = Draw["RunningTotal"].ToString();
                        dataGridView1.Rows[num].Cells[6].Value = Draw["Qty_Lama"].ToString();
                        dataGridView1.Rows[num].Cells[7].Value = Draw["TransactionGroup"].ToString();
                        dataGridView1.Rows[num].Cells[8].Value = Draw["TransactionStatus"].ToString();
                        dataGridView1.Rows[num].Cells[9].Value = Draw["StatusText"].ToString();
                        dataGridView1.Rows[num].Cells[10].Value = Draw["RecID"].ToString();

                    }

                }
                rdr_result.Close();

            }

            catch(Exception ex) {
                //Console.WriteLine(ex.ToString());
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Conn error");
            }
            conn.Close();
            progressBar1.Value = 0;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
